Based on this article: https://vorba.ch/2018/url-security-identicons.html

A firefox extension, which displays an identicon, based on the hostname of the current URL.

### Usage
Run with `./node_modules/web-ext/bin/web-ext run --firefox=/usr/bin/firefox`
